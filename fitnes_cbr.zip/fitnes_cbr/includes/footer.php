</main>
    <footer class="footer">
        <div class="container">
            <p>&copy; Sistem Pakar Fitness CBR 2025. </p>
        </div>
    </footer>
    <script src="<?php echo BASE_URL; ?>assets/js/script.js"></script>
</body>
</html>